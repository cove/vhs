# Ut Video Codec Suite  ZIP package  readme


## Warning

You MAY install and use Ut Video Codec Suite only if you agree to the license terms written in readme.en.html and gplv2.txt.

You SHOULD close all applications before installing/uninstalling Ut Video Codec Suite.

You SHOULD uninstall older version before installing this version.

You SHOULD uninstall this version before installing newer version, too.


## How to install

1. Right click "install.bat" and click "Run as Administrator" in context menu.
   - An UAC dialog might be displayed. Click "Yes".
2. License confirmation is displayed. Follow the instruction.
3. Some documents (including English and Japanese) are opened by your web browser.


## How to uninstall

1. Right click "uninstall.bat" and click "Run as Administrator" in context menu.
   - An UAC dialog might be displayed. Click "Yes".
